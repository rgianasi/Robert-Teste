const express = require('express');
const server = express();
const dados = require('./src/data/repositorio.json')
server.get('/repositorio',(req, res) => {

    return res.json(dados)
});

//feita a função para pegar os 
function getApiGitHub(){
fetch('https://github.com/orgs/takenet/repositories')
.then(async res => {
    if(!res.ok){
        throw new Error(res.status);
    }
    let data = await res.json()
})
}


server.get('data');

server.listen(3000,() => {
console.log('Servidor está funcionando')

});